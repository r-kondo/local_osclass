<?php $pluginInfo = osc_plugin_get_info('fb_page_plugin/index.php'); ?>

<div id="settings_form" style="border: 1px solid #ccc; background: #eee; ">
  <div style="padding: 0 20px 20px;">
    <div>
    	<p>Place following code into theme file wherever you need to show.</p>
    	<pre>&lt;?php fb_page_plugin(); ?&gt;</pre>
      
    </div>
  </div>
</div>
<p class="form-row">
  &copy; <?php echo date('Y'); ?> Facebook Page Plugin - <a href="<?php echo osc_admin_render_plugin_url('fb_page_plugin/admin.php'); ?>">Settings</a> - <a href="http://www.drizzlethemes.com/">DrizzleThemes</a>.
</p>
<div class="related-items">
<h3 style="margin-bottom:5px;">Premium Osclass Themes</h3>
<a href="http://www.drizzlethemes.com/products/flatter-responsive-theme-osclass/" target="_blank">Flatter Responsive Osclass Theme</a> &middot; <a href="http://www.drizzlethemes.com/products/liberty-responsive-theme-osclass/" target="_blank">Liberty Responsive Osclass Theme</a> &middot; <a href="http://www.drizzlethemes.com/products/boxer-responsive-theme-osclass/" target="_blank">Boxer Responsive Osclass Theme</a>
</div>
