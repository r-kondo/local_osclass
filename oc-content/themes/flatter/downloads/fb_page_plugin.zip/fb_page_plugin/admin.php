<style type="text/css">
	#content-page { background:#e5e5e5; }
	.form-container { width:500px; border:2px solid #ddd; background:#fff; }
	.form-container h2 { margin:0; padding:10px 15px; background:#47639e; color:#fff;}
	.form-container fieldset { padding:15px; }
	.control-group { margin-bottom:15px; }
	.control-label { margin-bottom:5px; display:block; }
	.form-actions { margin-top:15px; margin-bottom:0;}
	.form-horizontal .form-actions { padding-left:15px;}
	.form-container input[type=text] { padding:10px; width:95%; }
	.form-container input[type=text].swidth { width:30%; }
</style>
<?php $pluginInfo = osc_plugin_get_info('fb_page_plugin/index.php');  ?>
<div class="form-container form-horizontal">
<h2 class="render-title"><?php _e('Facebook Page Plugin Configuration', 'fb_page_plugin'); ?></h2>
<form action="<?php echo osc_admin_render_plugin_url('fb_page_plugin/admin.php'); ?>" method="post">
  <input type="hidden" name="fbpageoption" value="fbpagesettings" />
  <fieldset>
  <div class="control-group">
  	<label class="control-label"><?php _e('Facebook Page URL', 'fb_page_plugin'); ?></label>
    <div class="controls">
    	<input type="text" name="fb_page_url" value="<?php echo osc_esc_html(dd_fb_page_url()); ?>">
    </div>
  </div>
  <div class="control-group">
  	<label class="control-label"><?php _e('Width', 'fb_page_plugin'); ?></label>
    <div class="controls">
    	<input type="text" class="swidth" name="fb_page_width" value="<?php echo osc_esc_html(dd_fb_page_width()); ?>">
    </div>
  </div>
  <div class="control-group">
  	<label class="control-label"><?php _e('Height', 'fb_page_plugin'); ?></label>
    <div class="">
    	<input type="text" class="swidth" name="fb_page_height" value="<?php echo osc_esc_html(dd_fb_page_height()); ?>">
    </div>
  </div>
  <div class="control-group">
  	
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (dd_fb_show_faces() ? 'checked="true"' : ''); ?> name="fb_show_faces" id="fb_show_faces" value="true" />
        <label><?php _e('Show Friends Faces', 'fb_page_plugin'); ?></label>
    </div>
  </div>
  
  
  <div class="control-group">
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (dd_hide_page_cover() ? 'checked="false"' : ''); ?> name="hide_page_cover" id="hide_page_cover" value="false" />
        <label><?php _e('Show Cover Photo', 'fb_page_plugin'); ?></label>
    </div>
  </div>
  <div class="control-group">
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (dd_show_page_posts() ? 'checked="true"' : ''); ?> name="show_page_posts" id="show_page_posts" value="true" />
        <label><?php _e('Show Page Posts', 'fb_page_plugin'); ?></label>
    </div>
  </div>
  <div class="control-group">
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (dd_use_small_header() ? 'checked="true"' : ''); ?> name="use_small_header" id="use_small_header" value="true" />
        <label><?php _e('Use Small Header', 'fb_page_plugin'); ?></label>
    </div>
  </div>
  <div class="control-group">
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (dd_adapt_container_width() ? 'checked="true"' : ''); ?> name="adapt_container_width" id="adapt_container_width" value="true" />
        <label><?php _e('Adapt to container width', 'fb_page_plugin'); ?></label>
    </div>
  </div>
  </fieldset>
  <div class="form-actions">
    <input type="submit" value="<?php _e('Save changes', 'fb_page_plugin'); ?>" class="btn btn-submit">
  </div>
  
</form>
</div>
<div class="footer">
    <p class="form-row">
    &copy; <?php echo date('Y'); ?> Facebook Page Plugin - <a href="<?php echo osc_admin_render_plugin_url('fb_page_plugin/help.php'); ?>"><?php _e('Help', 'fb_page_plugin'); ?></a> - <a href="http://www.drizzlethemes.com/">DrizzleThemes</a>.
    </p>
</div>
<div class="related-items">
<h3 style="margin-bottom:5px;">Premium Osclass Themes</h3>
<a href="http://www.drizzlethemes.com/products/flatter-responsive-theme-osclass/" target="_blank">Flatter Responsive Osclass Theme</a> &middot; <a href="http://www.drizzlethemes.com/products/liberty-responsive-theme-osclass/" target="_blank">Liberty Responsive Osclass Theme</a> &middot; <a href="http://www.drizzlethemes.com/products/boxer-responsive-theme-osclass/" target="_blank">Boxer Responsive Osclass Theme</a>
</div>