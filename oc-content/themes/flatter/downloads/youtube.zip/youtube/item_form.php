<div class="form-group">
 <label style="margin:0px;" for="region" class="col-sm-3 control-label"><?php _e('Youtube video', 'youtube'); ?></label>
<div class="col-sm-8">
<input style="width:100%; margin-left:0;" type="text" name="s_youtube" value="<?php echo $detail['s_youtube'] ; ?>" />

<small> <?php printf( __( 'Enter the youtube url, i.e.: <em>%s</em> or <em>%s</em>', 'youtube' ), 'http://www.youtube.com/watch?v=ojqWclLQOxk', 'http://www.youtube.com/v/ojqWclLQOxk') ; ?></small>
 </div>
</div>